package ListaDeExercicios5.Ex1c;

public interface Iot {
    public void ligar();
    public void desligar();
}
