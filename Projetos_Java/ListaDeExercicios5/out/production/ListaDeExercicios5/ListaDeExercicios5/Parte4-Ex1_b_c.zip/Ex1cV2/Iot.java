package ListaDeExercicios5.Ex1cV2;

public interface Iot {
    public void ligar();
    public void desligar();
}
